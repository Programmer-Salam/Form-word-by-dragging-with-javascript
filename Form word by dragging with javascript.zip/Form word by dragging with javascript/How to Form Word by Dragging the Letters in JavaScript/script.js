function dragOver(e){
		e.preventDefault();
}
	
function drop(e){
	e.preventDefault();
	var data = e.dataTransfer.getData("data");
	
	document.getElementById('input').value += data;
}

function drag(e){
	e.dataTransfer.setData("data", e.target.id);
}

function submitData(){
	alert(document.getElementById('input').value);
}

function removeChar(){
	let input = document.getElementById('input');
	console.log(input.value);
	let val=input.value.slice(0, -1);
	input.value=val;
}

function clearAll(){
	document.getElementById('input').value = "";
}